#include "userwindow.h"
#include "ui_userwindow.h"
#include <QPixmap>
#include <map>
#include <string>
#include <QThread>
#include <iostream>
#include <chrono>

UserWindow::UserWindow(QWidget *parent, Peer& p) :
    QMainWindow(parent),
    ui(new Ui::UserWindow)
{
    cout << "Beginning: Constructing\n";
    this->p = &p;

    ui->setupUi(this);
    QPixmap pix("/home/saraseleem/Desktop/Steganogram/Steganogram/logo.png");
    ui->LogoLabel->setPixmap(pix.scaled(50,50,Qt::KeepAspectRatio));

    model = new QStringListModel(this);

    t = std::thread(&UserWindow::updateOnlineList,this);
}

void UserWindow::updateOnlineList()
{
    while (1) {
        model->setStringList(list);

        ui->usersList->setModel(model);

        std::map<string,pair<string,int> > list_1 = p->getStatus();
        std::map<string,pair<string,int> >::iterator it;

        for(it=list_1.begin();it!=list_1.end();++it)
        {
            list << (it->second.first).c_str();
            //list->addItem((it->second.first).c_str());
        }
        //list->update();
        list.removeDuplicates();
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
}

UserWindow::~UserWindow()
{
    t.join();
    delete ui;
}

