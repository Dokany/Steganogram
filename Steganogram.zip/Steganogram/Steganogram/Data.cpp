#include "Data.h"

Data::Data()
{
	flattened="";
}
string Data::getFlattenedData()
{
	return flattened;
}
Data::~Data()
{}